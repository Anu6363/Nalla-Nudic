import 'package:flutter/material.dart';

import '../data/sample_data.dart';
import '../models/term_model.dart';
import '../widgets/search_bar.dart';
import 'detail_screen.dart';

class SubjectScreen extends StatefulWidget {

  final String subject;

  const SubjectScreen({
    super.key,
    required this.subject,
  });

  @override
  State<SubjectScreen> createState() => _SubjectScreenState();
}

class _SubjectScreenState extends State<SubjectScreen> {

  List<TermModel> filteredTerms = [];

  @override
  void initState() {
    super.initState();

    filteredTerms = sampleTerms
        .where((term) => term.subject == widget.subject)
        .toList();
  }

  void searchTerm(String query) {

    final results = sampleTerms.where((term) {

      return term.subject == widget.subject &&
          term.english.toLowerCase().contains(
            query.toLowerCase(),
          );
    }).toList();

    setState(() {
      filteredTerms = results;
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: Text(widget.subject),
      ),

      body: Column(
        children: [

          SearchBarWidget(
            onChanged: searchTerm,
          ),

          Expanded(
            child: ListView.builder(

              itemCount: filteredTerms.length,

              itemBuilder: (context, index) {

                final term = filteredTerms[index];

                return Card(

                  margin: const EdgeInsets.all(10),

                  child: ListTile(

                    title: Text(term.english),

                    subtitle: Text(term.kannada),

                    trailing: const Icon(Icons.arrow_forward_ios),

                    onTap: () {

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DetailScreen(
                            term: term,
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

import '../database/database_helper.dart';
import '../models/term_model.dart';
import 'saved_screen.dart';

class DetailScreen extends StatelessWidget {

  final TermModel term;

  DetailScreen({
    super.key,
    required this.term,
  });

  final FlutterTts flutterTts = FlutterTts();

  Future speakWord() async {

    await flutterTts.speak(term.english);
  }

  Future saveWord(BuildContext context) async {

    try {

      await DatabaseHelper.instance.insertWord(term);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Word Saved Successfully'),
        ),
      );

    } catch (e) {

      print(e);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: Text(term.english),
      ),

      body: Padding(
        padding: const EdgeInsets.all(20),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,

          children: [

            Row(
              mainAxisAlignment:
              MainAxisAlignment.spaceBetween,

              children: [

                Text(
                  term.english,
                  style: const TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                IconButton(
                  onPressed: speakWord,
                  icon: const Icon(
                    Icons.volume_up,
                    size: 35,
                  ),
                )
              ],
            ),

            const SizedBox(height: 30),

            Text(
              term.kannada,
              style: const TextStyle(
                fontSize: 28,
                color: Colors.green,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 30),

            Text(
              term.explanation,
              style: const TextStyle(
                fontSize: 20,
              ),
            ),

            const SizedBox(height: 40),

            SizedBox(
              width: double.infinity,
              height: 55,

              child: ElevatedButton.icon(

                onPressed: () => saveWord(context),

                icon: const Icon(Icons.bookmark),

                label: const Text(
                  'Save Word',
                  style: TextStyle(fontSize: 18),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
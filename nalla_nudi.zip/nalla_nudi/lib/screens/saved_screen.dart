import 'package:flutter/material.dart';

import '../database/database_helper.dart';
import '../models/term_model.dart';

class SavedScreen extends StatefulWidget {

  const SavedScreen({super.key});

  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> {

  List<TermModel> savedWords = [];

  @override
  void initState() {
    super.initState();

    loadWords();
  }

  Future loadWords() async {

    final data =
    await DatabaseHelper.instance.getSavedWords();

    setState(() {
      savedWords = data;
    });
  }

  Future deleteWord(int id) async {

    await DatabaseHelper.instance.deleteWord(id);

    loadWords();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: const Text('Saved Words'),
      ),

      body: savedWords.isEmpty

          ? const Center(
        child: Text(
          'No Saved Words',
          style: TextStyle(fontSize: 20),
        ),
      )

          : ListView.builder(

        itemCount: savedWords.length,

        itemBuilder: (context, index) {

          final word = savedWords[index];

          return Card(

            margin: const EdgeInsets.all(10),

            child: ListTile(

              title: Text(word.english),

              subtitle: Text(word.kannada),

              trailing: IconButton(

                onPressed: () {

                  deleteWord(word.id!);
                },

                icon: const Icon(
                  Icons.delete,
                  color: Colors.red,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
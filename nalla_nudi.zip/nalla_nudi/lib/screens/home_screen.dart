import 'package:flutter/material.dart';

import 'saved_screen.dart';
import 'subject_screen.dart';

class HomeScreen extends StatelessWidget {

  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text('Nalla-Nudi'),
        centerTitle: true,
        actions: [

          IconButton(
            onPressed: () {

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const SavedScreen(),
                ),
              );
            },
            icon: const Icon(Icons.bookmarks),
          )
        ],
      ),

      body: Padding(
        padding: const EdgeInsets.all(20),

        child: Column(
          children: [

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.blue.shade100,
                borderRadius: BorderRadius.circular(20),
              ),

              child: const Column(
                children: [

                  Text(
                    'Word of the Day',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  SizedBox(height: 10),

                  Text(
                    'Gravity → ಗುರುತ್ವಾಕರ್ಷಣೆ',
                    style: TextStyle(fontSize: 18),
                  )
                ],
              ),
            ),

            const SizedBox(height: 40),

            subjectButton(
              context,
              'Science',
              Colors.green,
            ),

            const SizedBox(height: 20),

            subjectButton(
              context,
              'Mathematics',
              Colors.orange,
            ),

            const SizedBox(height: 20),

            subjectButton(
              context,
              'Commerce',
              Colors.purple,
            ),
          ],
        ),
      ),
    );
  }

  Widget subjectButton(
      BuildContext context,
      String subject,
      Color color,
      ) {

    return SizedBox(
      width: double.infinity,
      height: 60,

      child: ElevatedButton(

        style: ElevatedButton.styleFrom(
          backgroundColor: color,
        ),

        onPressed: () {

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SubjectScreen(
                subject: subject,
              ),
            ),
          );
        },

        child: Text(
          subject,
          style: const TextStyle(
            fontSize: 20,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}
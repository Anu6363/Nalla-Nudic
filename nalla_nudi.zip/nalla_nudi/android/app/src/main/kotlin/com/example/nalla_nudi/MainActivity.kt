package com.example.nalla_nudi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
